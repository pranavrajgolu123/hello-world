
def cli_to_uri(ip,port,objs):
     url='https://'+ip+ ":"+str(port)+"/"+"/".join(objs)
     return url
    

#http://
def main():
        username = raw_input("What is your name? ")
	# verb 
	# payload
	url = cscli_to_uri('127.0.0.1',8080,['users','admins',username])
        print url
	#request.post(url,payload)

if __name__ == '__main__':
	main()
