import click
import requests
from Clusterstorclient.cli import pass_context
@click.group()
@click.option('--string', '-n', multiple=True, default='', help='Who are you?')

@pass_context
def cli(ctx,string):
    pass

@cli.group()
#@click.option('--string1', '-n', multiple=True, default='', help='Who are you?')
def admin():
     pass

@cli.group()
def guest():
     pass

@cli.group()
def config():
     pass

@admin.command('show')
@click.argument('name')


def show(name):
     "Admin Help"
     click.echo('call from admin')
     click.echo('Hello %s!' % name)

     req = requests.get(name)

     click.echo(req.encoding)      # returns 'utf-8'
     click.echo(req.status_code)   # returns 200
     click.echo(req.elapsed)
     click.echo(req.url)


@guest.command('show')


def show():
     "guest Help"
     click.echo('call from guest')



@config.command('show')


def show():
     "config Help"
     click.echo('call from config')



