import click
from Clusterstorclient.cli import pass_context
from Clusterstorclient.cli import cli_to_url

 

@click.group()
@click.option('--string',default='user2',help='welcome to user2')
@pass_context
def cli(ctx,string):
    """cscli users"""
    pass

# cscli users admins
@cli.group()
def admins():
     "Manage admin accounts."
     pass

# cscli users guests
@cli.group()
def guest():
     pass

# cscli users configs
@cli.group()
def config():
     pass


@admins.command('add')
@click.option('--enable_ssh/--disable_ssh', default=True, help=''' Enables/Disables SSH for the specified admin account (default:SSH enabled).''')
@click.option('--enable_web/--disable_web', default=True, help=''' Enables/Disables web access for the specified admin account(default: web enabled.''')
@click.option('--username',required=True, help='Specifies the name of the user.')
@click.option('--firstname', help='Specifies the users first name.')
@click.option('--lastname', help='Specifies the users last name.')

@click.option('--password_policy', help='''Creates the user account with the specified password
                        policy. Specifying this will take precedence over
                        '--stream-api'. If not specified, then 'default'
                        password policy will be used.''')
@click.option('--role', required=True, help='''Displays available roles; Select one from the list:
                        {full, limited, readonly}.''')
@click.option('--password', prompt=True, confirmation_prompt=True,hide_input=True, help='Sets the password of the specified admin account.')
@click.pass_context
def add(ctx, role, password_policy, password, username, lastname, firstname, enable_web, enable_ssh):
     "Creates a new admin account."
     click.echo('Hello %s!' % username)
     click.echo('call from add')
     
     #main(username)

@admins.command('list')
def list():
     "Displays all the available admin accounts, except default admin account, namely {admin}"
     click.echo('call from list')
     
@admins.command('show')
@click.option('--username',required=True, help='Specifies the name of the user.')
@click.pass_context
def show(ctx,username):
     "Displays details of the specified admin account."
     click.echo('call from show')
     

@admins.command('remove')
def remove():
     "Removes the specified admin account."
     click.echo('call from show')

@admins.command('modify')
@click.option('--username',required=True, help='Specifies the name of the user.')
@click.option('--new_firstname', help='Specifies a new first name.')
@click.option('--new_lastname', help='Specifies a new last name.')
@click.option('--new_role', help='''Displays available roles; Select one from the list:
                        {full, limited, readonly}.''')
@click.option('--new_shell', help='''Displays available shells; Select one from the list:
                        {bash, rcsh}.''')
def modify(ctx,username,old_firstname,new_lastname,new_shell,new_role):
     "Modifies preferences for the specified admin account."
     click.echo('call from show')

@admins.command('reset_password')
@click.option('--username',required=True, help='Specifies the name of the user.')
@click.option('--old_password', help='Specifies your old password.')
@click.option('--new_password', help='Specifies your new password.')

def rest_password(username,old_password,new_password):
     "Resets the password for the specified admin account."
     click.echo('call from show')

@admins.command('enable')
@click.option('--username',required=True, help='Specifies the name of the user.')
def enable():
     "Enables the specified admin account."
     click.echo('call from show')

@admins.command('disable')
@click.option('--username',required=True, help='Specifies the name of the user.')
def disable():
     "Disables the specified admin account"
     click.echo('call from show')

#admins policy command
@admins.group()
def policy():
     'policy group'
     pass


@policy.command('list')
def list():
     "Enables the specified admin account."
     click.echo('call from list')
    

@policy.command('show')
def show():
     "Enables the specified admin account."
     click.echo('call from show')


@policy.command('add')
def add():
     "Enables the specified admin account."
     click.echo('call from add')

@policy.command('set')
def set():
     "Enables the specified admin account."
     click.echo('call from set')


@policy.command('remove')
def remove():
     "Enables the specified admin account."
     click.echo('call from remove')




#guest command

@guest.command('show')
def show():
     "guest Help"
     click.echo('call from guest')


#config command

@config.command('show')
def show():
     "config Help"
     click.echo('call from config')



